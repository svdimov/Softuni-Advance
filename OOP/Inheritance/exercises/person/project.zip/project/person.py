class Person:
    def __init__(self,name:str,age:int):
        self.age = age
        self.name = name
