from project.sports_car import SportsCar

s_car = SportsCar()

print(s_car.race())
print(s_car.move())
print(s_car.drive())