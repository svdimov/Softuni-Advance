from project.fruit import Fruit
f = Fruit('apple','20-20-2024')
print(f.print_output())