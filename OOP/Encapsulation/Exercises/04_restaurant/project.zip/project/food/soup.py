from project.food.starter import Starter


class Soup(Starter):
   pass



