# Kohinoor is successfully added to the auction as RenaissanceArtifact.
# Zelda is successfully added to the auction as RenaissanceArtifact.
# Mona Lisa is successfully added to the auction as RenaissanceArtifact.
# The Scream is successfully added to the auction as ContemporaryArtifact.
# Untitled is successfully added to the auction as ContemporaryArtifact.
#
# Josh Smith is successfully registered as a PrivateCollector.
# Louvre is successfully registered as a Museum.
# Hermitage is successfully registered as a Museum.
#
# Josh Smith purchased Mona Lisa for a price of 10000.00.
# Louvre purchased Kohinoor for a price of 5000.00.
# Josh Smith purchased Zelda for a price of 5000.00.
# Josh Smith purchased The Scream for a price of 2000.00.
# Purchase is impossible.
#
# No such artifact.
# No such artifact.
#
# 2 collector/s increased their available money.
#
# **Auction statistics**
# Total number of sold artifacts: 4
# Available artifacts for sale: 1
# ***
# Collector name: Josh Smith; Money available: 13000.00; Space available: 1890; Artifacts: Zelda, The Scream, Mona Lisa
# Collector name: Louvre; Money available: 11000.00; Space available: 1990; Artifacts: Kohinoor
# Collector name: Hermitage; Money available: 15000.00; Space available: 2000; Artifacts: none
#
# Removed Contemporary Artifact: Untitled; Price: 32000.00; Required space: 90
